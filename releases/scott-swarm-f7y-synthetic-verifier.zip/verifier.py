import argparse
from contextlib import closing
import base64
import ctypes
import hashlib
import json
import sqlite3
import sys
from ctypes import wintypes

ORDER = (
    "domain", "audience", "operation", "scope",
    "run_id", "policy_sha256", "manifest_sha256",
    "approval_id", "nonce", "issued", "expires"
)

DOMAIN = "SCOTT_SWARM_F7Y_B_SYNTHETIC_V1"
AUDIENCE = "SCOTT_SWARM_INDEPENDENT_TEST"

def canonical(fields):
    if set(fields) != set(ORDER):
        raise ValueError("FIELDS")
    parts = []
    for name in ORDER:
        value = fields[name]
        if name in ("issued", "expires"):
            if type(value) is not int:
                raise ValueError("TIME_TYPE")
        elif type(value) is not str:
            raise ValueError("FIELD_TYPE")
        value = str(value)
        if "|" in value or "\n" in value or "\r" in value:
            raise ValueError("DELIMITER")
        parts.append(value)
    return "|".join(parts).encode("ascii")

def decode(value):
    return base64.b64decode(value, validate=True)

def verify_cng(message, signature, public):
    if (len(public) != 72 or public[:4] != b"ECS1"
            or int.from_bytes(public[4:8], "little") != 32
            or len(signature) != 64):
        return False

    dll = ctypes.WinDLL("bcrypt.dll")
    H = ctypes.c_void_p
    D = wintypes.DWORD

    def bind(name, args):
        fn = getattr(dll, name)
        fn.argtypes = args
        fn.restype = ctypes.c_long
        return fn

    op = bind("BCryptOpenAlgorithmProvider",
              [ctypes.POINTER(H), wintypes.LPCWSTR,
               wintypes.LPCWSTR, D])
    imp = bind("BCryptImportKeyPair",
               [H, H, wintypes.LPCWSTR, ctypes.POINTER(H),
                H, D, D])
    verify = bind("BCryptVerifySignature",
                  [H, H, H, D, H, D, D])
    destroy = bind("BCryptDestroyKey", [H])
    close = bind("BCryptCloseAlgorithmProvider", [H, D])

    provider = H()
    key = H()
    rc = op(ctypes.byref(provider), "ECDSA_P256", None, 0)
    if rc != 0:
        raise RuntimeError("CNG_PROVIDER")

    try:
        pb = ctypes.create_string_buffer(public)
        rc = imp(provider, None, "ECCPUBLICBLOB",
                 ctypes.byref(key), pb, len(public), 0)
        if rc != 0:
            return False

        digest = hashlib.sha256(message).digest()
        dh = ctypes.create_string_buffer(digest)
        sg = ctypes.create_string_buffer(signature)

        return verify(key, None, dh, len(digest),
                      sg, len(signature), 0) == 0
    finally:
        if key.value:
            destroy(key)
        if provider.value:
            close(provider, 0)

def verify_request(fields, sig, anchor, clock,
                   nominated=None):
    if nominated is not None and nominated != anchor:
        return "UNTRUSTED_SIGNER"

    if fields["domain"] != DOMAIN:
        return "DOMAIN"
    if fields["audience"] != AUDIENCE:
        return "AUDIENCE"
    if fields["operation"] != "SHADOW_ENROLL":
        return "OPERATION"
    if fields["scope"] != "SHADOW_ONLY":
        return "SCOPE"

    for key, size in (
        ("run_id", 32),
        ("policy_sha256", 64),
        ("manifest_sha256", 64),
        ("nonce", 32)
    ):
        value = fields[key]
        if len(value) != size or any(
            c not in "0123456789abcdef" for c in value
        ):
            return "FORMAT"

    issued = fields["issued"]
    expires = fields["expires"]

    if issued > clock + 30:
        return "FUTURE"
    if expires <= clock or expires <= issued:
        return "EXPIRED"
    if expires - issued > 600:
        return "LIFETIME"

    try:
        data = canonical(fields)
    except (ValueError, UnicodeError):
        return "MALFORMED"

    if not verify_cng(data, sig, anchor):
        return "SIGNATURE"

    return "VALID"

def initialize(path):
    with closing(sqlite3.connect(path, timeout=10)) as db:
        db.execute("PRAGMA journal_mode=DELETE")
        db.execute("PRAGMA synchronous=FULL")
        db.execute("""
            CREATE TABLE consumed (
                approval_id TEXT PRIMARY KEY,
                nonce TEXT NOT NULL UNIQUE,
                run_id TEXT NOT NULL
            )
        """)
        db.execute("""
            CREATE TABLE tombstone (
                run_id TEXT PRIMARY KEY
            )
        """)
        db.commit()

def admit(path, fields, sig, anchor, clock, nominated=None):
    result = verify_request(fields, sig, anchor, clock, nominated)
    if result != "VALID":
        return result

    with closing(sqlite3.connect(path, timeout=15,
                         isolation_level=None)) as db:
        try:
            db.execute("BEGIN IMMEDIATE")
            if db.execute(
                "SELECT 1 FROM tombstone WHERE run_id=?",
                (fields["run_id"],)
            ).fetchone():
                db.execute("ROLLBACK")
                return "REPLAY"

            db.execute(
                "INSERT INTO consumed VALUES (?,?,?)",
                (fields["approval_id"],
                 fields["nonce"], fields["run_id"])
            )
            db.execute(
                "INSERT INTO tombstone VALUES (?)",
                (fields["run_id"],)
            )
            db.execute("COMMIT")
            return "ADMITTED_SYNTHETIC"

        except sqlite3.IntegrityError:
            db.execute("ROLLBACK")
            return "REPLAY"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=("init", "admit", "inspect"))
    ap.add_argument("database")
    ap.add_argument("--anchor")
    ap.add_argument("--vectors")
    ap.add_argument("--clock", type=int)
    ns = ap.parse_args()

    if ns.action == "init":
        initialize(ns.database)
        print("DATABASE_INITIALIZED")
        return

    if ns.action == "inspect":
        with sqlite3.connect(
            "file:" + ns.database.replace("\\", "/") +
            "?mode=ro", uri=True
        ) as db:
            db.execute("PRAGMA query_only=ON")
            integrity = db.execute(
                "PRAGMA integrity_check"
            ).fetchone()[0]
            consumed = db.execute(
                "SELECT COUNT(*) FROM consumed"
            ).fetchone()[0]
            tombstones = db.execute(
                "SELECT COUNT(*) FROM tombstone"
            ).fetchone()[0]
        print("INTEGRITY=" + integrity)
        print("CONSUMED=" + str(consumed))
        print("TOMBSTONES=" + str(tombstones))
        return

    if not ns.anchor or not ns.vectors or ns.clock is None:
        raise ValueError("ARGS_MISSING")

    with open(ns.anchor, encoding="utf-8") as f:
        anchor_data = json.load(f)
    with open(ns.vectors, encoding="utf-8") as f:
        vector = json.load(f)

    if anchor_data["algorithm"] != "ECDSA_P256_SHA256":
        raise ValueError("ALGORITHM")

    anchor = decode(anchor_data["public_blob_base64"])
    signature = decode(vector["signature_base64"])

    result = admit(
        ns.database, vector["fields"],
        signature, anchor, ns.clock
    )
    print("ADMISSION=" + result)

    if result not in ("ADMITTED_SYNTHETIC", "REPLAY"):
        sys.exit(20)

if __name__ == "__main__":
    main()