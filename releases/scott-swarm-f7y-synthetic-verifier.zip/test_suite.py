import base64
import copy
import json
import os
import pathlib
import subprocess
import sys
import tempfile
import time

ROOT = pathlib.Path(__file__).resolve().parent
VERIFIER = ROOT / "verifier.py"

sys.path.insert(0, str(ROOT))
import verifier as v

with open(ROOT / "anchor.json", encoding="utf-8") as f:
    anchor_data = json.load(f)
with open(ROOT / "vectors.json", encoding="utf-8") as f:
    vectors = json.load(f)

public = base64.b64decode(anchor_data["public_blob_base64"])
rogue_public = base64.b64decode(vectors["rogue_public_base64"])
signature = base64.b64decode(vectors["signature_base64"])
rogue_signature = base64.b64decode(
    vectors["rogue_signature_base64"]
)
fields = vectors["fields"]
clock = vectors["reference_clock"]

passed = 0

def test(name, condition):
    global passed
    if not condition:
        raise RuntimeError("TEST_FAILED:" + name)
    passed += 1
    print("TEST={} PASS=True".format(name), flush=True)

test("01-canonical-fixture",
     v.canonical(fields).decode("ascii")
     == vectors["canonical_ascii"])

test("02-valid-signature",
     v.verify_request(fields, signature, public, clock)
     == "VALID")

test("03-rogue-signature",
     v.verify_request(fields, rogue_signature, public, clock)
     == "SIGNATURE")

test("04-worker-nominated-key",
     v.verify_request(fields, signature, public, clock,
                      rogue_public) == "UNTRUSTED_SIGNER")

def changed(name, value, expected):
    copy_fields = copy.deepcopy(fields)
    copy_fields[name] = value
    return v.verify_request(
        copy_fields, signature, public, clock
    ) == expected

test("05-forbidden-scope",
     changed("scope", "PRODUCTION", "SCOPE"))
test("06-forbidden-operation",
     changed("operation", "MAINNET_ARM", "OPERATION"))
test("07-wrong-audience",
     changed("audience", "OTHER", "AUDIENCE"))
test("08-changed-policy",
     changed("policy_sha256", "0" * 64, "SIGNATURE"))
test("09-changed-manifest",
     changed("manifest_sha256", "0" * 64, "SIGNATURE"))
test("10-expired-request",
     v.verify_request(fields, signature, public,
                      fields["expires"] + 1) == "EXPIRED")
test("11-future-issued",
     v.verify_request(fields, signature, public,
                      fields["issued"] - 100) == "FUTURE")

with tempfile.TemporaryDirectory(
    prefix="ScottSwarm-F7YB-"
) as temporary:
    db = str(pathlib.Path(temporary) / "test.sqlite3")
    v.initialize(db)

    test("12-first-admission",
         v.admit(db, fields, signature,
                 public, clock) == "ADMITTED_SYNTHETIC")
    test("13-replay-after-reopen",
         v.admit(db, fields, signature,
                 public, clock) == "REPLAY")

    # Second database for independently launched processes.
    race_db = str(pathlib.Path(temporary) / "race.sqlite3")
    v.initialize(race_db)

    command = [
        sys.executable, "-I", "-B",
        str(VERIFIER), "admit", race_db,
        "--anchor", str(ROOT / "anchor.json"),
        "--vectors", str(ROOT / "vectors.json"),
        "--clock", str(clock)
    ]

    a = subprocess.Popen(
        command, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, text=True
    )
    b = subprocess.Popen(
        command, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, text=True
    )

    try:
        ao, ae = a.communicate(timeout=20)
        bo, be = b.communicate(timeout=20)
    except subprocess.TimeoutExpired:
        for p in (a, b):
            if p.poll() is None:
                p.kill()
            p.communicate()
        raise RuntimeError("CONCURRENCY_TIMEOUT")

    results = [ao.strip(), bo.strip()]

    test("14-two-process-exit-success",
         a.returncode == 0 and b.returncode == 0
         and not ae and not be)
    test("15-exactly-one-concurrent-admission",
         results.count("ADMISSION=ADMITTED_SYNTHETIC") == 1
         and results.count("ADMISSION=REPLAY") == 1)

    import sqlite3
    with __import__("contextlib").closing(sqlite3.connect(race_db)) as conn:
        counts = (
            conn.execute(
                "SELECT COUNT(*) FROM consumed"
            ).fetchone()[0],
            conn.execute(
                "SELECT COUNT(*) FROM tombstone"
            ).fetchone()[0]
        )
        integrity = conn.execute(
            "PRAGMA integrity_check"
        ).fetchone()[0]

    test("16-race-persistent-ledger",
         counts == (1, 1) and integrity == "ok")

print("TESTS_PASSED={}/16".format(passed))
print("CONCURRENT_PROCESSES=2")
print("CONCURRENT_SUCCESSFUL_ADMISSIONS=1")
print("CONCURRENT_REPLAY_REJECTIONS=1")
print("EXTERNAL_KEY_CUSTODY=NOT_PROVEN")
print("OPERATOR_CONSENT=NOT_PROVEN")
print("REAL_ENROLLMENT=NONE")